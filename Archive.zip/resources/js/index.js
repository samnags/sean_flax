$(document).ready(() => { 

    $.localScroll();

})